# Sample_Expencetracker restdb React
Sample_Expencetracker React/Mobx app.

Demo: https://jsdevpro.pl/expencetracker/

## Installation:

## Use git clone.
```
git clone https://github.com/jaman7/Sample_Expencetracker.git
```
## install
```
yarn install
```

## run command

```
gulp
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## License
[MIT](https://choosealicense.com/licenses/mit/)