<?php

?>

<!DOCTYPE html>
<html lang="pl-PL">

	<head>
		<title>Sample_Expencetracker</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700&display=swap&subset=latin-ext" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
	</head>

	<body>

		<section id="transaction" class="transaction transaction-bg"></section>
		<script data-main="js/main" src="js/jsvendor/require.js">
		</script>

	</body>

</html>
