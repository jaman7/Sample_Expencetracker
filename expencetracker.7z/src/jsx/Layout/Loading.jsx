import React from 'react';

const Loading = () => <img src="img/gif-load.svg" alt="" />;

export default Loading;
