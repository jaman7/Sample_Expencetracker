import React from 'react';

const Trashicon = () => <i className="fas fa-trash-alt" title="Remove" />;

export default Trashicon;
