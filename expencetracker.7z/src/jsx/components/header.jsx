import React from 'react';

export const Header = () => (
	<div className="col-12 py-3">
		<h2 className="transaction-header">Expense Tracker</h2>
	</div>
);

export default Header;
